//BankImpl.java
//
//implementation of the Bank
//
import java.io.*;
import java.util.*;

public class BankImpl implements Bank {
	private int n; // the number of threads in the system
	private int m; // the number of resources

	private Vector<Integer> available; // the amount available of each resource
	private Vector<Vector<Integer>> maximum; // the maximum demand of each thread
	private Vector<Vector<Integer>> allocation; // the amount currently allocated to each thread
	private Vector<Vector<Integer>> need; // the remaining needs of each thread
	private Vector<Boolean> shutdown;
	
	private void showAllMatrices(Vector<Vector<Integer>> alloc, Vector<Vector<Integer>> max, Vector<Vector<Integer>> need, String msg) {
		System.out.println("        Allocated      MAXIMUM        NEED");
		for (int i = 0; i < n; i++) {
			if (shutdown.get(i) == true) {
				System.out.println("        ------         ------         ------");
			} else {
				showVector(alloc.get(i), "        ");
				int maxPrefixSpaceLen = 15 - (2 + alloc.get(i).size() * 2 - 1);
				String maxPrefix = "";
				for (int j = 0; j < maxPrefixSpaceLen; j++) {
					maxPrefix += " ";
				}
				showVector(max.get(i), maxPrefix);
				showVector(need.get(i), maxPrefix);
				System.out.println();
			}	
		}
	}

	private void showMatrix(Vector<Vector<Integer>> matrix, String title, String rowTitle) {
		System.out.println("        title");
		for (int i = 0; i < matrix.size(); i++) {
			System.out.print(rowTitle);
			showVector(matrix.get(i), "  ");
		}
	}

	private void showVector(Vector<Integer> vect, String msg) {
		String vectStr = stringifyVector(vect);

		System.out.print(msg + vectStr);
	}

	private String stringifyVector(Vector<Integer> v) {
		StringBuilder sb = new StringBuilder();
		String prefix = "[";
		String surfix = "]";
		
		for (int i = 0; i < v.size(); i++) {
			sb.append(v.get(i) + " ");
		}
		
		return prefix + sb.toString().trim() + surfix;
	}
	
	public BankImpl(Vector<Integer> resources) { // create a new bank (with resources)
		this.m = resources.size();
		this.n = Customer.COUNT;
		
		shutdown = new Vector<>();
		available = new Vector<>(resources);
		
		maximum = new Vector<>();
		for (int i = 0; i < n; i++) {
			Vector<Integer> temp = new Vector<>();
			for (int j = 0; j < m; j++) {
				temp.add(0);
			}
			maximum.add(new Vector<Integer>(temp));
		}
		
		allocation = new Vector<>();
		for (int i = 0; i < n; i++) {
			Vector<Integer> temp = new Vector<>();
			for (int j = 0; j < m; j++) {
				temp.add(0);
			}
			allocation.add(new Vector<Integer>(temp));
		}
		
		need = new Vector<>();
		for (int i = 0; i < n; i++) {
			Vector<Integer> temp = new Vector<>();
			for (int j = 0; j < m; j++) {
				temp.add(0);
			}
			need.add(new Vector<Integer>(temp));
		}
		
		for (int i = 0; i < n; i++) {
			shutdown.add(false);
		}
		
	}

	public Vector<Integer> getCurrentNeeds(int threadNum) {		
		return new Vector<Integer>(this.need.get(threadNum));
	}
	
	// invoked by a thread when it enters the system; also records max demand
	public void addCustomer(int threadNum, Vector<Integer> allocated, Vector<Integer> maxDemand) {
		System.out.println("adding customer " + threadNum + "...");
		this.allocation.set(threadNum, allocated);
		this.maximum.set(threadNum, maxDemand);
		
		for (int i = 0; i < m; i++) {
			this.need.get(threadNum).set(i, this.maximum.get(threadNum).get(i) - this.allocation.get(threadNum).get(i));
		}
	}

	public void getState() { // output state for each thread
		showAllMatrices(this.allocation, this.maximum, this.need, "");
	}

	private boolean isSafeState(int threadNum, Vector<Integer> request) {
		boolean isSafe = true;
		
		//is not safe if request larger than available
		for (int i = 0; i < m; i++) {
			if (request.get(i) > this.need.get(threadNum).get(i)) return false;
			if (request.get(i) > this.available.get(i)) return false;
		}
		
		//init safe state check matrix
		Vector<Integer> work = new Vector<>(this.available);
		
		//check if there is a permutation of all threads can lead to a safe state
		boolean[] checked = new boolean[n];
		Arrays.fill(checked, false);
		
		ArrayList<List<Integer>> safeStates = new ArrayList<>();
		ArrayList<Integer> temp = new ArrayList<>();
		
		backtrack(safeStates, temp, checked, work);
		
		if (safeStates.isEmpty() == true) isSafe = false;
		
		return isSafe;
	}
	
	private void backtrack(ArrayList<List<Integer>> safeStates, ArrayList<Integer> temp, boolean[] checked, Vector<Integer> work) {
		if (safeStates.isEmpty() == false) return;
		
		if (temp.size() == n) {
			safeStates.add(new ArrayList(temp));
			return;
		}
		
		for (int i = 0; i < n; i++) {
			if (checked[i] == true) continue;
			//if thread i is available, check if it is in safe state currently
			boolean safe = true;
			for (int j = 0; j < m; j++) {
				if (work.get(j) < this.need.get(i).get(j)) {
					safe = false;
					break;
				}
			}
			if (safe == false) continue;
			
			//add current thread to safe sequence
			temp.add(i);
			
			//update needCopy and allocationCopy and work after thread i finished
			for (int j = 0; j < m; j++) {
				work.set(j, work.get(j) + this.maximum.get(i).get(j));
			}
			
			checked[i] = true;
			
			backtrack(safeStates, temp, checked, work);
			
			//backtrack to the previous state after checking current state
			checked[i] = false;
			
			for (int j = 0; j < m; j++) {
				work.set(j, work.get(j) - this.maximum.get(i).get(j));
			}
			
			temp.remove(temp.size() - 1);
		}
		
	}

	// make request for resources. will block until request is satisfied safely
	public synchronized boolean requestResources(int threadNum, Vector<Integer> request) { 
		
		boolean approveRequest = isSafeState(threadNum, request);
		
		//print request information message
		System.out.print("#P" + threadNum);
		showVector(request, " RQ:");
		showVector(this.need.get(threadNum), ", needs:");
		showVector(this.available, ", available");
		
		//print request decision message
		if (approveRequest == true) {
			//update allocation and need matrix
			for (int i = 0; i < m; i++) {
				this.allocation.get(threadNum).set(i, this.allocation.get(threadNum).get(i) + request.get(i));
				this.need.get(threadNum).set(i, this.need.get(threadNum).get(i) - request.get(i));
				this.available.set(i, this.available.get(i) - request.get(i));
			}
			
			System.out.print("   ---> APPROVED, #P" + threadNum);
			showVector(this.allocation.get(threadNum), " now at:");
			showVector(this.available, "\navailable ");
			System.out.println();
		} else {
			System.out.println(" DENIED");
		}
			
		//print all matrix information
		if (approveRequest == true) {
			getState();
		}
		
		return approveRequest;
	}

	public synchronized void releaseResources(int threadNum, Vector<Integer> release)  {
		//check if current thread has already got all resources and thus shut down
		boolean needShutdown = true;
		for (int i = 0; i < m; i++) {
			if (this.need.get(threadNum).get(i) != 0) {
				needShutdown = false;
				break;
			}
		}
		
		if (needShutdown == true) {
			shutdown.set(threadNum, true);
			//return resources to resource pool
			for (int i = 0; i < m; i++) {
				this.available.set(i, this.available.get(i) + this.maximum.get(threadNum).get(i));
			}
			
			Thread.currentThread().interrupt();
			System.out.println("------------------------------> #P" + threadNum + " has all its resources!  RELEASING ALL and SHUTTING DOWN...");
			
			System.out.print("======================== customer #" + threadNum);
			showVector(release, " releasing:");
			showVector(this.allocation.get(threadNum), ", allocated=");
			System.out.println();
		} 
	}
}
