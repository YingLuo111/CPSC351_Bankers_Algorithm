******************************
* How to Compile the Program *
******************************
Compile the program using the following command:
javac -Xlint -classpath . BankersAlgorithmSimulation.java
or
javac -classpath . BankersAlgorithmSimulation.java

**************************
* How to Run the Program *
**************************
java BankersAlgorithmSimulation ./infile.txt ./bankers_small.txt ./bankers_tiny.txt ./bankers_medium.txt ./bankers_large.txt