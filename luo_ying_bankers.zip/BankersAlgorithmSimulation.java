import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.*;
import java.util.concurrent.Semaphore;


//--------------------------------------------------------------------------
// class BankersAlgorithm
// --------------------------------------------------------------------------
public class BankersAlgorithmSimulation {
  public static PrintStream so = System.out;
  static Semaphore mutex = new Semaphore(1);
  static Semaphore issafe_mutex = new Semaphore(1);
  static Vector<Thread> workers = new Vector<>();
  
  static void runSimulation() {
    so.println("\nBanker's algorithm simulation beginning...\n--------------------------------------------");

    for (Thread w : workers) {
      w.start();
    }
  }

  //============================================== confirms argc > 1
  private static void verify(String[] args) {
    if (args.length == 0) {
      so.println("Usage: java bankers filename1 [filename2 filename3 ...]");
      System.exit(1);
    }
  }

  private static void processLine(String buf, Vector<Integer> values) {    // gets values from one line
	String[] line_data = buf.split(",");
    values.clear();
    for (String num : line_data) {
      int val = Integer.parseInt(num.trim());
      values.add(val);      // convert to int, add to int array
    }
  }

  private static void processFile(String filename) {    // extracts avail for Bank, customers' alloc and max
    String buf = null;
    Vector<Integer> res = new Vector<>();
   File file = new File(filename);      // pass the path to the file as a parameter
    // String filePath = System.getProperty("user.dir") + "/src/bankerWithVectors/" + filename.trim();
    // File file = new File(filePath);
    Scanner sc = null;
    Bank bank = null;
    int numResources = 0;
	int numCustomer = countCustomers(filename);
	Customer.COUNT = numCustomer;
	
    try {
      sc = new Scanner(file);
    } catch(FileNotFoundException e) {
      so.println("\n\nWarning, could not open file: '" + filename + "'");
    }

    so.println("\n\nProcessing file: '" + filename + "'...");
    boolean firstLine = true;
    int idx = 0;
    while (sc.hasNextLine()) {
      buf = sc.nextLine();
      if (buf.length() == 0) { break; }

      processLine(buf, res);
      if (firstLine) {    // first line has bank's resources
        Vector<Integer> avail = new Vector<>(res);
        numResources = avail.size();
        bank = new BankImpl(avail);
        firstLine = false;
      } else {
        Vector<Integer> alloc = new Vector<>();
        Vector<Integer>  max  = new Vector<>();
        for (int i = 0; i < numResources; ++i) {
          alloc.add(res.get(i));            // e.g., for size = 2,  0, 1
          max.add(res.get(i + numResources));       // ditto,               2, 3
        }
        
        Customer c = new Customer(idx, max, bank);
        workers.add(new Thread(c));
        bank.addCustomer(idx, alloc, max);
        idx++;
      }
    }
    
    sc.close();
  }

  private static int countCustomers(String filename) {
		try {
	    	File inputFile = new File(filename);
	    	Scanner inputScanner = new Scanner(inputFile);
	    	int totalLines = 0;
	    	
	    	while (inputScanner.hasNextLine()) {
	    		String line = inputScanner.nextLine();
	    		if (line.length() == 0) continue;
	    		totalLines++;
	    	}
    	
	    	inputScanner.close();
	    	return totalLines - 1;
	    } catch(FileNotFoundException fnfe) {
	    	throw new Error("Unable to find file \"" + filename + "\"");
	    // } catch(IOException ioe) { 
	    // 	throw new Error("Error processing \"" + filename + "\""); 
	    }
  }
  
  private static void processFiles(String[] args) {    // processes all files in command line
    for (String filename : args) {
      workers.clear();
      processFile(filename);

      if (workers.isEmpty()) {
        so.println("\t\tNo customers found... exiting...\n\n");
        System.exit(1);
      }
      runSimulation();
      
      for (Thread w : workers) {
          try {
			w.join();
          } catch (InterruptedException e) {
          }
        }
      so.println("\n\n");
    }
  }

  public static void main(String[] args) {
	verify(args);
    processFiles(args);
    System.out.println("Processed all files. Exiting program...");
  }
}

