import java.util.Vector;

//Customer.java
//
public class Customer implements Runnable {
	public static int COUNT; // number of threads

	private int numOfResources; // N different resources
	private Vector<Integer> maxDemand; // maximum this thread will demand
	private int customerNum; // customer number
	private Vector<Integer> request; // request it is making

	private java.util.Random rand; // random number generator

	private Bank theBank; // synchronizing object

	public Customer(int customerNum, Vector<Integer> maxDemand, Bank theBank) {
		this.customerNum = customerNum;
		this.maxDemand = new Vector<Integer>(maxDemand);
		this.theBank = theBank;

		numOfResources = maxDemand.size();
		request = new Vector<>();
		for (int i = 0; i < maxDemand.size(); i++) {
			request.add(0);
		}
		rand = new java.util.Random();
	}

	public void run() {
		boolean canRun = true;
		while (canRun) {
			try {
				SleepUtilities.nap(); // take a nap
										// ... then, make a resource request
				this.maxDemand = ((BankImpl)theBank).getCurrentNeeds(this.customerNum);
				
				for (int i = 0; i < numOfResources; i++) {
					request.set(i, rand.nextInt(maxDemand.get(i) + 1));
				}

				if (theBank.requestResources(customerNum, request)) { // if customer can proceed
					SleepUtilities.nap(); // use and release the resources
					theBank.releaseResources(customerNum, request);
				}
			} catch (InterruptedException ie) {
				canRun = false;
			}
		}
	}
}
