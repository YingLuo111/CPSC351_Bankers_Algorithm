import java.util.Vector;

//Bank.java
//
public interface Bank {
	// add customer to Bank
	public void addCustomer(int threadNum, Vector<Integer> maxDemand, Vector<Integer> allocated); 

	// outputs available, allocation, max, and need matrices
	public void getState(); 

	// request resources; specify number of customer being added, maxDemand for customer
	// returns if request is grant
	public boolean requestResources(int threadNum, Vector<Integer> request);

	// release resources
	public void releaseResources(int threadNum, Vector<Integer> release);
}
